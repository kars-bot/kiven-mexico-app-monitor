import gplay from 'google-play-scraper';
import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

export const root = dirname(fileURLToPath(import.meta.url));
export const reportDir = resolve(root, 'reports');
const options = { timeout: { request: 30000 }, retry: { limit: 1 } };
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
export async function config() {
  const c = JSON.parse(await readFile(resolve(root, 'config.json'), 'utf8'));
  if (!/^[a-z]{2}$/.test(c.country) || !/^[a-z]{2}$/.test(c.lang)) throw new Error('国家和语言必须是两个小写英文字母');
  if (!Number.isInteger(c.reviewsPerApp) || c.reviewsPerApp < 1 || c.reviewsPerApp > 300) throw new Error('每个 App 评论数须在 1–300 之间');
  if (!Number.isInteger(c.requestDelayMs) || c.requestDelayMs < 1000 || c.requestDelayMs > 60000) throw new Error('请求间隔须为 1000–60000 毫秒');
  if (!Array.isArray(c.apps) || c.apps.length > 20) throw new Error('监控名单最多 20 个 App');
  for (const app of c.apps) {
    if (!app || !/^[\w]+(?:\.[\w]+)+$/.test(app.appId)) throw new Error('监控名单中存在无效的 App ID');
  }
  if (new Set(c.apps.map(a => a.appId)).size !== c.apps.length) throw new Error('监控名单不能有重复 App ID');
  return c;
}

export function csv(rows, columns) {
  const cell = value => {
    let s = value == null ? '' : typeof value === 'object' ? JSON.stringify(value) : String(value);
    if (/^[\s]*[=+\-@]/.test(s)) s = "'" + s;
    return '"' + s.replaceAll('"', '""') + '"';
  };
  return '\uFEFF' + [columns.map(cell).join(','), ...rows.map(row => columns.map(key => cell(row[key])).join(','))].join('\r\n');
}

async function saveJson(path, value) {
  await mkdir(dirname(path), { recursive: true });
  const temp = path + '.tmp';
  await writeFile(temp, JSON.stringify(value, null, 2) + '\n');
  await rename(temp, path);
}

function common(c) { return { country: c.country, lang: c.lang, requestOptions: options, throttle: 1 }; }
function details(a) {
  return {
    appId: a.appId, title: a.title, developer: a.developer, score: a.score,
    ratings: a.ratings, reviews: a.reviews, installs: a.installs,
    version: a.version, updated: a.updated, summary: a.summary,
    description: a.description, recentChanges: a.recentChanges,
    url: a.url, genre: a.genre, histogram: a.histogram,
  };
}

export async function search(term, num = 5) {
  const c = await config();
  if (typeof term !== 'string' || !term.trim() || term.length > 100) throw new Error('搜索词须为 1–100 个字符');
  const apps = await gplay.search({ ...common(c), term: term.trim(), num: Math.max(1, Math.min(10, Number(num) || 5)), fullDetail: false });
  return apps.map(a => ({ query: term, appId: a.appId, title: a.title, developer: a.developer, score: a.score, url: a.url, country: c.country, lang: c.lang, confirmed: false }));
}

export async function discover() {
  const c = await config();
  const candidates = [], errors = [];
  for (const term of c.searchTerms ?? []) {
    try { candidates.push(...await search(term)); }
    catch (e) { errors.push({ term, error: e.message }); }
    await pause(c.requestDelayMs);
  }
  await saveJson(resolve(reportDir, 'candidates.json'), { generatedAt: new Date().toISOString(), candidates, errors });
  await writeFile(resolve(reportDir, 'candidates.csv'), csv(candidates, ['query', 'title', 'appId', 'developer', 'score', 'url', 'confirmed']));
  return { candidates, errors };
}

export async function inspect(appId, reviewCount = 5) {
  const c = await config();
  if (!/^[\w]+(?:\.[\w]+)+$/.test(appId)) throw new Error('无效的 App ID');
  const app = details(await gplay.app({ ...common(c), appId }));
  await pause(c.requestDelayMs);
  const result = await gplay.reviews({ ...common(c), appId, sort: gplay.sort.NEWEST, num: reviewCount });
  if (!Array.isArray(result.data)) throw new Error('评论接口返回格式异常');
  const reviews = result.data.map(r => ({
    id: r.id, appId, appTitle: app.title, score: r.score,
    date: r.date, text: r.text, version: r.version, thumbsUp: r.thumbsUp,
    replyText: r.replyText, replyDate: r.replyDate,
  }));
  return { app, reviews };
}

let running = false;
export async function collect() {
  if (running) { const e = new Error('已有一次抓取正在进行'); e.status = 409; throw e; }
  const c = await config();
  if (c.apps.length === 0) { const e = new Error('尚未设置监控 App。先查看 candidates.csv，再将确认的 App ID 填入 config.json 的 apps。'); e.status = 422; throw e; }
  running = true;
  try {
    const startedAt = new Date().toISOString();
    let previous = { apps: {} };
    try { previous = JSON.parse(await readFile(resolve(reportDir, 'state.json'), 'utf8')); }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
    const next = structuredClone(previous);
    const apps = [], reviews = [], changes = [], errors = [];
    for (const entry of c.apps) {
      let result;
      try { result = await inspect(entry.appId, c.reviewsPerApp); }
      catch (e) { errors.push({ appId: entry.appId, error: e.message }); continue; }
      const { app, reviews: fetched } = result;
      app.role = entry.role ?? 'competitor';
      const before = previous.apps[entry.appId];
      const seen = new Set(before?.seenReviewIds ?? []);
      apps.push({ ...app, baseline: !before });
      for (const r of fetched) reviews.push({ ...r, role: app.role, isNew: before ? !seen.has(r.id) : false, baseline: !before });
      if (before) {
        for (const field of ['title', 'developer', 'score', 'ratings', 'installs', 'version', 'summary', 'description', 'recentChanges']) {
          if (JSON.stringify(before.details[field]) !== JSON.stringify(app[field])) changes.push({ appId: app.appId, title: app.title, field, before: before.details[field] ?? null, after: app[field] ?? null });
        }
      }
      next.apps[entry.appId] = { details: app, seenReviewIds: [...new Set([...fetched.map(r => r.id), ...seen])].slice(0, 10000) };
      await pause(c.requestDelayMs);
    }
    const report = {
      startedAt, finishedAt: new Date().toISOString(), country: c.country, lang: c.lang,
      status: errors.length === 0 ? 'ok' : apps.length ? 'partial' : 'failed',
      summary: { apps: apps.length, baselineApps: apps.filter(a => a.baseline).length, reviews: reviews.length, newReviews: reviews.filter(r => r.isNew).length, changes: changes.length, errors: errors.length },
      note: '首次采集建立基线。评论为本次返回的最新样本，新增数不代表商店完整新增量。日期使用 UTC ISO 格式。',
      apps, reviews, changes, errors,
    };
    const folder = resolve(reportDir, startedAt.replaceAll(':', '-'));
    await saveJson(resolve(folder, 'report.json'), report);
    await writeFile(resolve(folder, 'apps.csv'), csv(apps, ['role', 'title', 'appId', 'developer', 'score', 'ratings', 'installs', 'version', 'updated', 'summary', 'url', 'baseline']));
    await writeFile(resolve(folder, 'reviews.csv'), csv(reviews, ['role', 'appTitle', 'appId', 'id', 'score', 'date', 'text', 'version', 'replyText', 'isNew', 'baseline']));
    await writeFile(resolve(folder, 'changes.csv'), csv(changes, ['title', 'appId', 'field', 'before', 'after']));
    await saveJson(resolve(reportDir, 'latest.json'), { ...report, folder });
    if (apps.length) await saveJson(resolve(reportDir, 'state.json'), next);
    return { ...report, folder };
  } finally { running = false; }
}

import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const workerFile = fileURLToPath(new URL('./cli.mjs', import.meta.url));
const failure = (message, status) => Object.assign(new Error(message), { status });

// Run collection outside the HTTP process so a hung scraper can actually be
// terminated before releasing the slot. A Promise timeout alone leaves it alive.
export class CollectionJob {
  constructor({ worker = workerFile, args = ['collect'], timeoutMs = 240000, clock = Date.now, validate = report => ['ok', 'partial', 'failed'].includes(report.status) && Array.isArray(report.apps) && Array.isArray(report.reviews) } = {}) {
    this.worker = worker;
    this.args = args;
    this.timeoutMs = timeoutMs;
    this.clock = clock;
    this.validate = validate;
    this.current = null;
    this.last = null;
    this.closed = false;
  }

  status() {
    const job = this.current;
    return { running: Boolean(job), startedAt: job?.startedAt ?? null,
      elapsedMs: job ? this.clock() - job.startedMs : 0,
      timeoutMs: this.timeoutMs, last: this.last };
  }

  run() {
    if (this.closed) return Promise.reject(failure('采集服务正在重启，请稍后重试。', 503));
    if (this.current) {
      const old = this.current;
      // A sleeping laptop can resume with expired work before its timer fires.
      if (this.clock() - old.startedMs >= this.timeoutMs) {
        old.expired = true;
        old.child.kill('SIGKILL');
        return old.promise.catch(() => {}).then(() => this.run());
      }
      return old.promise;
    }
    const job = { startedAt: new Date(this.clock()).toISOString(), startedMs: this.clock(), stopping: false };
    this.current = job;
    const { SCRAPER_API_KEY: unused, ...workerEnv } = process.env;
    job.promise = new Promise((resolve, reject) => {
      job.child = execFile(process.execPath, [this.worker, ...this.args], {
        timeout: this.timeoutMs, killSignal: 'SIGKILL', maxBuffer: 16 * 1024 * 1024,
        env: workerEnv,
      }, (error, stdout) => {
        if (job.stopping) return reject(failure('采集服务正在重启，请稍后重试。', 503));
        if (job.expired || error?.killed) return reject(failure(`本轮采集超过 ${this.timeoutMs / 1000} 秒或输出上限，已终止并释放任务，请重试。`, 504));
        let report;
        try { report = JSON.parse(stdout); } catch {
          return reject(failure('采集进程异常退出，未生成完整报告；任务已释放，可重试。', 502));
        }
        if (!this.validate(report)) {
          return reject(failure('采集报告格式异常，任务已释放，可重试。', 502));
        }
        if (error && report.status === 'ok') return reject(failure('采集进程异常退出，未标记成功。', 502));
        resolve(report);
      });
    }).then(report => {
      this.last = { startedAt: job.startedAt, finishedAt: new Date().toISOString(),
        status: report.status, apps: report.apps?.length ?? 0, reviews: report.reviews?.length ?? 0 };
      return report;
    }, error => {
      this.last = { startedAt: job.startedAt, finishedAt: new Date().toISOString(),
        status: 'failed', error: error.message };
      throw error;
    }).finally(() => { if (this.current === job) this.current = null; });
    return job.promise;
  }

  stop() {
    this.closed = true;
    if (this.current) {
      this.current.stopping = true;
      this.current.child.kill('SIGKILL');
    }
  }
}

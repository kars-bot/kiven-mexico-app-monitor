import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {CollectionJob} from './collection-job.mjs';
import {publicRanking,rankDay,rankFile,readRankings} from './ranking-model.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
export const rankingDir=path.join(root,'reports/rankings');
export async function saveRanking(raw){
 const config=JSON.parse(await fs.readFile(path.join(root,'config.json'),'utf8')),clean=publicRanking(raw,config);
 await fs.mkdir(rankingDir,{recursive:true});
 await fs.writeFile(path.join(rankingDir,rankFile(clean)),JSON.stringify(clean),{flag:'wx'});return clean;
}
const job=new CollectionJob({worker:path.join(root,'ranking-worker.mjs'),args:[],timeoutMs:45000,validate:r=>['ok','failed'].includes(r.status)&&Array.isArray(r.apps)&&r.category==='FINANCE'});
export async function runRankings(){
 try{return await job.run()}catch{
  const capturedAt=new Date().toISOString();
  return saveRanking({schemaVersion:1,capturedAt,day:rankDay(capturedAt),country:'mx',category:'FINANCE',collection:'TOP_FREE',status:'failed'});
 }
}
export async function todayRanking(){
 const config=JSON.parse(await fs.readFile(path.join(root,'config.json'),'utf8')),rows=await readRankings(rankingDir,config),now=new Date().toISOString(),due=Date.parse(rankDay(now)+'T11:30:00+08:00');
 return rows.find(r=>r.day===rankDay(now)&&r.status==='ok'&&(Date.now()<due||Date.parse(r.capturedAt)>=due));
}

import fs from 'node:fs/promises';
import path from 'node:path';
export const rankDay = value => new Date(Date.parse(value) + 28800000).toISOString().slice(0,10);
export const rankFile = r => r.capturedAt.replaceAll(':','-') + '.json';
export function publicRanking(raw, config) {
 const iso = s => typeof s === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(s) && Number.isFinite(Date.parse(s));
 if(raw.schemaVersion!==1 || !iso(raw.capturedAt) || raw.day!==rankDay(raw.capturedAt) || raw.country!=='mx' || raw.category!=='FINANCE' || raw.collection!=='TOP_FREE' || !['ok','failed'].includes(raw.status)) throw Error('排名快照格式无效。');
 const base={schemaVersion:1,capturedAt:raw.capturedAt,day:raw.day,country:'mx',lang:'es',category:'FINANCE',collection:'TOP_FREE',source:'Google Play',status:raw.status};
 if(raw.status==='failed')return {...base,coverage:0,apps:[],chart:[],error:'本次榜单采集失败，保留此前成功快照。'};
 const ids=new Set(config.apps.map(a=>a.appId));
 if(!Array.isArray(raw.chart)||raw.chart.length<100||raw.chart.length>200||new Set(raw.chart.map(a=>a.appId)).size!==raw.chart.length||raw.chart.some(a=>typeof a.appId!=='string'||!/^[\w]+(?:\.[\w]+)+$/.test(a.appId)||typeof a.title!=='string'||a.title.length>500))throw Error('榜单返回不完整或格式异常，未将应用误记为未上榜。');
 if(!Array.isArray(raw.apps)||raw.apps.length!==ids.size||new Set(raw.apps.map(a=>a.appId)).size!==ids.size||raw.apps.some(a=>!ids.has(a.appId)))throw Error('排名应用名单与监控配置不一致。');
 const chart=raw.chart.map(a=>({appId:a.appId,title:a.title}));
 const apps=raw.apps.map(a=>{const position=chart.findIndex(x=>x.appId===a.appId),rank=position<0?null:position+1;if(a.rank!==rank)throw Error('排名与原始榜单位置不一致。');return {appId:a.appId,rank}});
 return {...base,coverage:chart.length,apps,chart};
}
export async function readRankings(dir,config){
 let names;try{names=await fs.readdir(dir)}catch(e){if(e.code==='ENOENT')return [];throw e}
 const rows=[];for(const name of names.filter(n=>/^\d{4}-.*\.json$/.test(n))){rows.push(publicRanking(JSON.parse(await fs.readFile(path.join(dir,name),'utf8')),config))}
 return rows.sort((a,b)=>a.capturedAt.localeCompare(b.capturedAt));
}
export function rankingData(rows){
 const byDay=new Map();
 for(const r of rows){const old=byDay.get(r.day);const due=Date.parse(r.day+'T11:30:00+08:00');
  // First successful sample at/after the daily target wins; retries never rewrite it.
  if(!old || (old.status!=='ok'&&r.status==='ok') || (old.status==='ok'&&r.status==='ok'&&Date.parse(old.capturedAt)<due&&Date.parse(r.capturedAt)>=due))byDay.set(r.day,r);
 }
 return {schemaVersion:1,country:'mx',category:'FINANCE',collection:'TOP_FREE',source:'Google Play',targetTime:'11:30',timeZone:'Asia/Shanghai',latestAttempt:rows.at(-1)?.capturedAt??null,days:[...byDay.values()].map(({chart,...r})=>r),captures:rows.map(({chart,...r})=>r)};
}

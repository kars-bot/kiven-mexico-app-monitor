import gplay from 'google-play-scraper';
import fs from 'node:fs/promises';
import {saveRanking,todayRanking} from './ranking-job.mjs';
import {rankDay} from './ranking-model.mjs';
const existing=await todayRanking();
if(existing){console.log(JSON.stringify(existing));process.exit(0)}
const capturedAt=new Date().toISOString();
const base={schemaVersion:1,capturedAt,day:rankDay(capturedAt),country:'mx',lang:'es',category:'FINANCE',collection:'TOP_FREE'};
let report;
try{
 const config=JSON.parse(await fs.readFile(new URL('./config.json',import.meta.url),'utf8'));
 const chart=await gplay.list({country:'mx',lang:'es',category:gplay.category.FINANCE,collection:gplay.collection.TOP_FREE,num:200,fullDetail:false,requestOptions:{timeout:{request:15000},retry:{limit:0}}});
 report=await saveRanking({...base,status:'ok',chart,apps:config.apps.map(a=>{const n=chart.findIndex(x=>x.appId===a.appId);return {appId:a.appId,rank:n<0?null:n+1}})});
}catch{report=await saveRanking({...base,status:'failed'})}
console.log(JSON.stringify(report));

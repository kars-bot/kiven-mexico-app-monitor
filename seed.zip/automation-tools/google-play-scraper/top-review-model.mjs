// Preserve the server's MOST_RELEVANT order. Never sort/filter by stars first.
const iso=s=>typeof s==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(s)&&Number.isFinite(Date.parse(s));
export const topDay=s=>new Date(Date.parse(s)+8*3600000).toISOString().slice(0,10);
const fields=['id','score','date','text','version','thumbsUp','replyText','replyDate'];
export function publicTopReviews(captures,config){
 if(!Array.isArray(captures)||captures.length>config.apps.length)throw Error('Top10 快照格式异常。');
 const ids=new Set(config.apps.map(a=>a.appId)),seen=new Set();
 return captures.map(c=>{
  if(!ids.has(c.appId)||seen.has(c.appId)||!iso(c.capturedAt)||c.sort!=='MOST_RELEVANT'||(c.sortCode!==undefined&&c.sortCode!==1)||!['ok','failed'].includes(c.status)||!Array.isArray(c.reviews)||c.reviews.length>10||(c.status==='failed'&&c.reviews.length))throw Error('Top10 快照字段无效。');
  seen.add(c.appId);const reviews=[],reviewIds=new Set();
  for(const r of c.reviews){
   if(typeof r.id!=='string'||!r.id||reviewIds.has(r.id)||!Number.isInteger(r.score)||r.score<1||r.score>5||!iso(r.date)||fields.some(k=>r[k]!=null&&typeof r[k]==='object'))throw Error('Top10 评论字段无效。');
   reviewIds.add(r.id);reviews.push(Object.fromEntries(fields.filter(k=>r[k]!==undefined).map(k=>[k,r[k]])));
  }
  return {appId:c.appId,capturedAt:c.capturedAt,sort:'MOST_RELEVANT',...(c.sortCode===1?{sortCode:1}:{}),status:c.status,reviews};
 });
}
export function topReviewData(reports){
 // Only explicit Google sort-code-1 captures qualify for this metric.
 const captures=reports.flatMap(r=>r.topReviews??[]).filter(c=>c.sortCode===1).toSorted((a,b)=>a.capturedAt.localeCompare(b.capturedAt));
 const daily=new Map();
 for(const c of captures){
  const day=topDay(c.capturedAt),key=day+':'+c.appId,old=daily.get(key),due=Date.parse(day+'T11:30:00+08:00');
  // First successful capture per app/day, preferring captures at/after 11:30.
  const successful=v=>v.status==='ok'&&v.reviews.length>0;
  if(!old||(successful(c)&&!successful(old))||(successful(c)&&successful(old)&&Date.parse(old.capturedAt)<due&&Date.parse(c.capturedAt)>=due))daily.set(key,c);
 }
 const days=[...daily.values()].map(c=>{const sampleCount=c.reviews.length,fiveStarCount=c.reviews.filter(r=>r.score===5).length;return {...c,day:topDay(c.capturedAt),sampleCount,fiveStarCount,share:c.status==='ok'&&sampleCount?fiveStarCount/sampleCount:null}}).toSorted((a,b)=>a.day.localeCompare(b.day)||a.appId.localeCompare(b.appId));
 return {schemaVersion:1,sort:'MOST_RELEVANT',country:'mx',lang:'es',collectionStart:captures[0]?.capturedAt??null,latestBatch:reports.at(-1)?.startedAt??null,days};
}

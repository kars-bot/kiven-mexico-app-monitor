import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readReports,buildModel,shortName,sourceUrl,THEMES,FIELD_NAMES} from './report-model.mjs';
import {readRankings,rankingData} from '../google-play-scraper/ranking-model.mjs';
import {publicTopReviews,topReviewData} from '../google-play-scraper/top-review-model.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const pick=(o,keys)=>Object.fromEntries(keys.filter(k=>o[k]!==undefined).map(k=>[k,o[k]]));
export async function websiteData(){
 const sourceReports=await readReports(path.join(root,'google-play-scraper/reports'));
 const config=JSON.parse(await fs.readFile(path.join(root,'google-play-scraper/config.json'),'utf8'));
 const model=buildModel(sourceReports,config.apps);
 const reports=model.reports.map(r=>r.topReviews?{...r,topReviews:publicTopReviews(r.topReviews,config)}:r);
 const snapshots={};
 for(const r of reports){
  const observed=model.observations.filter(x=>x.batch===r.startedAt);
  const apps=r.apps.map(a=>({...pick(a,['appId','title','developer','score','ratings','reviews','installs','version','updated','summary','description','recentChanges','role']),name:shortName(a),url:sourceUrl(a.appId)}));
  snapshots[r.startedAt]={schemaVersion:1,startedAt:r.startedAt,finishedAt:r.finishedAt,country:'mx',lang:'es',apps,
   reviews:observed.map(a=>pick(a,['id','appId','appTitle','title','role','score','date','text','version','thumbsUp','replyText','replyDate','themes','discovery'])),
   changes:(r.changes??[]).map(c=>({...pick(c,['appId','title','field','before','after']),fieldName:FIELD_NAMES[c.field]??c.field})),
   errors:r.errors.map(e=>({appId:e.appId,error:'采集失败，请检查后续批次'}))};
  if(r.topReviews)snapshots[r.startedAt].topReviews=r.topReviews;
 }
 const index={schemaVersion:1,latestBatch:reports.at(-1).startedAt,schedule:'每天北京时间 11:30',themes:THEMES.map(([name])=>name),
  totals:{batches:reports.length,observations:model.observations.length,uniqueReviews:model.uniqueRows.length},
  apps:model.summaries.map(s=>({appId:s.app.appId,name:shortName(s.app),title:s.app.title??s.app.name??s.app.appId,role:s.app.role})),
  batches:reports.toReversed().map(r=>({startedAt:r.startedAt,finishedAt:r.finishedAt,apps:r.apps.length,reviews:r.reviews.length,errors:r.errors.length}))};
 const unique=new Map();
 for(const snapshot of Object.values(snapshots))for(const review of snapshot.reviews)unique.set(review.appId+':'+review.id,review);
 const history={schemaVersion:1,latestBatch:index.latestBatch,collectionStart:reports[0].startedAt,reviews:[...unique.values()],changes:Object.values(snapshots).flatMap(s=>s.changes.map(c=>({...c,collectedAt:s.startedAt})))};
 index.historyFile='history.json';
 index.rankingsFile='rankings.json';
 index.topReviewsFile='top-reviews.json';
 const rankings=rankingData(await readRankings(path.join(root,'google-play-scraper/reports/rankings'),config));
 return {index,snapshots,history,rankings,topReviews:topReviewData(reports)};
}
if(process.argv.includes('--seed')){
 const out=path.resolve(root,'../sites/mexico-app-monitor/data/seed.json');await fs.mkdir(path.dirname(out),{recursive:true});
 const data=await websiteData();await fs.writeFile(out,JSON.stringify(data));console.log(JSON.stringify({batches:data.index.batches.length,totals:data.index.totals,bytes:(await fs.stat(out)).size}));
}

import fs from 'node:fs/promises';
import path from 'node:path';

export const THEMES = [
  ['到账与提款', ['deposit', 'transfer', 'retiro', 'retirar', 'desembolso', 'no lleg']],
  ['申请与登录', ['registro', 'registrar', 'iniciar sesion', 'ingresar', 'verificacion', 'codigo', 'solicitud', 'solicitar']],
  ['还款与扣款', ['pago', 'pagar', 'pagado', 'cobran', 'cobraron', 'domicili', 'liquidar']],
  ['利息与费用', ['interes', 'comision', 'tarifa', 'costo', 'tasa', 'caro', 'costoso']],
  ['额度与审批', ['limite', 'monto', 'aumento', 'aproba', 'rechaz', 'autoriza', 'buro']],
  ['客服与沟通', ['atencion', 'soporte', 'servicio al cliente', 'asesor', 'responden']],
  ['催收与骚扰', ['cobranza', 'acoso', 'acosan', 'amenaz', 'hostiga', 'contactos', 'llamadas']],
  ['安全与诈骗疑虑', ['fraude', 'estafa', 'robo', 'robar', 'engan', 'datos personales']],
];
export const FIELD_NAMES = {
  score: '商店评分', ratings: '累计评分人数', reviews: '商店文字评论数', installs: '安装量区间',
  version: '版本', title: '应用名称', developer: '开发者', summary: '商店简介',
  description: '商店完整说明', recentChanges: '版本更新说明',
};
const SHORT_NAMES = {
  'com.elaworld.mexloan': 'MexDin', 'com.mercadopago.wallet': 'Mercado Pago',
  'com.didiglobal.cashloan': 'DiDi Finanzas', 'com.kueski.os': 'Kueski',
  'com.nu.production': 'Nu', 'com.clipcd.clipgo': 'Mi Clip',
  'com.fintopia.mxcredmex': 'Credmex', 'com.duxifinanzas.finance': 'Duxi Finanzas',
  'com.mexicash.app': 'MexiCash', 'com.crediclic.mx': 'MontoClic',
  'com.quieroya.prestamo.loan.cash.credit.mx': 'Qrece', 'mx.com.tala': 'Tala',
  'com.baubap': 'Baubap', 'com.sggaanalista.rapikredito': 'Rápikrédito',
  'com.dinero.fd.mx.loan': 'FortaPrest', 'mx.creo.credit': 'Booya',
  'com.navinext.facildin': 'FácilDin', 'com.kiven.mx': 'Kiven',
};
export const identity = role => role === 'self' ? '自家产品' : '竞品';
export const shortName = app => SHORT_NAMES[app.appId] ?? app.title ?? app.appTitle ?? app.appId;
export const sourceUrl = id => 'https://play.google.com/store/apps/details?id=' + encodeURIComponent(id) + '&hl=es&gl=mx';
export const beijingDate = value => value == null || value === '' ? null : new Date(new Date(value).getTime() + 8 * 3600000);
export const beijingText = value => beijingDate(value)?.toISOString().slice(0, 16).replace('T', ' ') ?? '未提供';
const plain = text => String(text ?? '').normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
export function themesFor(text) {
  const normalized = plain(text);
  return THEMES.filter(([, words]) => words.some(w => w === 'interes' ? /\binteres(?:es)?\b/.test(normalized) : normalized.includes(w))).map(([name]) => name);
}
export function splitText(value, length = 360) {
  const chars = Array.from(value ?? '');
  if (!chars.length) return [''];
  const chunks = [];
  for (let i = 0; i < chars.length; i += length) chunks.push(chars.slice(i, i + length).join(''));
  return chunks;
}
export async function readReports(reportDir) {
  const entries = await fs.readdir(reportDir, { withFileTypes: true });
  const reports = [];
  for (const e of entries.filter(e => e.isDirectory()).sort((a, b) => a.name.localeCompare(b.name))) {
    const file = path.join(reportDir, e.name, 'report.json');
    try {
      const report = JSON.parse(await fs.readFile(file, 'utf8'));
      if (!report.startedAt || !Array.isArray(report.apps) || !Array.isArray(report.reviews) || !Array.isArray(report.errors)) throw new Error('采集报告字段不完整：' + e.name);
      report.sourceFile = file;
      reports.push(report);
    } catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  reports.sort((a, b) => a.startedAt.localeCompare(b.startedAt));
  if (!reports.length) throw new Error('尚无已完成的采集报告');
  if (new Set(reports.map(r => r.startedAt)).size !== reports.length) throw new Error('采集批次时间重复，须先核对来源');
  return reports;
}
export function buildModel(reports, configuredApps = []) {
  const configuredRoles = new Map(configuredApps.filter(a => a.role).map(a => [a.appId, a.role]));
  // Identity is current configuration; keep original historical source files intact.
  reports = reports.map(report => ({ ...report,
    apps: report.apps.map(app => ({ ...app, role: configuredRoles.get(app.appId) ?? app.role })),
    reviews: report.reviews.map(review => ({ ...review, role: configuredRoles.get(review.appId) ?? review.role })),
  }));
  const history = [], observations = [], changes = [], copyRows = [];
  const unique = new Map(), appHistory = new Map();
  for (const report of reports) {
    const currentApps = new Map(report.apps.map(a => [a.appId, a]));
    const seenWithinBatch = new Set();
    for (const app of report.apps) {
      const row = { ...app, batch: report.startedAt };
      history.push(row);
      if (!appHistory.has(app.appId)) appHistory.set(app.appId, []);
      appHistory.get(app.appId).push({ ...row, excelRow: history.length + 6 });
      for (const field of ['summary', 'description', 'recentChanges']) {
        const parts = splitText(app[field]);
        parts.forEach((text, i) => copyRows.push({ batch: report.startedAt, app, field, part: i + 1, parts: parts.length, text }));
      }
    }
    for (const review of report.reviews) {
      if (!review.id || !review.appId) throw new Error('评论缺少去重标识');
      const key = review.appId + '\u0000' + review.id;
      if (seenWithinBatch.has(key)) throw new Error('同一批次内存在重复评论：' + review.appId);
      seenWithinBatch.add(key);
      const old = unique.get(key);
      const app = currentApps.get(review.appId) ?? { appId: review.appId, title: review.appTitle, role: review.role };
      const observed = { ...review, title: app.title, appTitle: review.appTitle, role: review.role ?? app.role, batch: report.startedAt, themes: themesFor(review.text), discovery: old ? '此前见过' : review.baseline ? '基线已有' : '首次发现' };
      observations.push(observed);
      unique.set(key, { ...observed, firstSeen: old?.firstSeen ?? report.startedAt, lastSeen: report.startedAt, observations: (old?.observations ?? 0) + 1 });
    }
    for (const change of report.changes ?? []) changes.push({ ...change, batch: report.startedAt });
  }
  const latest = reports.at(-1), latestObservations = observations.filter(r => r.batch === latest.startedAt);
  const lastKeys = new Set(latestObservations.map(r => r.appId + '\u0000' + r.id));
  const uniqueRows = [...unique.entries()].map(([key, r]) => ({ ...r, inLatest: lastKeys.has(key) }))
    .sort((a, b) => b.firstSeen.localeCompare(a.firstSeen) || a.score - b.score || shortName(a).localeCompare(shortName(b)) || a.id.localeCompare(b.id));
  const configuredIds = new Set(configuredApps.map(a => a.appId));
  const ids = [...new Set([...configuredApps.map(a => a.appId), ...appHistory.keys()])];
  const summaries = ids.map(id => {
    const snapshots = appHistory.get(id) ?? [];
    const app = snapshots.at(-1) ?? configuredApps.find(a => a.appId === id) ?? { appId: id };
    const samples = latestObservations.filter(r => r.appId === id);
    const failure = latest.errors.find(e => e.appId === id);
    return { app, previous: snapshots.at(-2), current: snapshots.at(-1), samples,
      fresh: app.batch === latest.startedAt,
      status: failure ? '采集失败' : app.batch === latest.startedAt ? '采集成功' : configuredIds.has(id) ? '本轮未覆盖' : '历史应用',
      error: failure?.error ?? '', newCount: samples.filter(r => r.discovery === '首次发现').length,
      lowCount: samples.filter(r => Number.isFinite(r.score) && r.score <= 2).length,
    };
  }).sort((a, b) => (a.app.role === 'self' ? -1 : 0) - (b.app.role === 'self' ? -1 : 0));
  const topics = THEMES.map(([name, words]) => {
    const matched = latestObservations.filter(r => r.themes.includes(name));
    return { name, words, count: matched.length, low: matched.filter(r => r.score <= 2).length };
  });
  return { reports, latest, history, observations, uniqueRows, changes, copyRows, summaries, topics, latestObservations };
}
export function briefMarkdown(m) {
  const latest = m.latest;
  const changes = (latest.changes ?? []).filter(c => c.field === 'version');
  const self = m.summaries.filter(a => a.app.role === 'self');
  const low = m.latestObservations.filter(r => r.score <= 2).length;
  const escape = s => String(s ?? '未提供').replaceAll('|', '\\|').replaceAll('\n', ' ');
  const top = [...m.topics].sort((a, b) => b.low - a.low).filter(t => t.low).slice(0, 3);
  const lines = [
    '# 墨西哥应用监控简报', '',
    `数据截至：${beijingText(latest.finishedAt)}（北京时间）。计划每天 11:30 更新。`, '',
    `累计完成 ${m.reports.length} 轮采集，保留 ${m.observations.length.toLocaleString('en-US')} 条采样记录，按应用与评论 ID 去重后为 ${m.uniqueRows.length.toLocaleString('en-US')} 条评论。`, '',
    `本轮成功采集 ${latest.apps.length} 个应用，失败 ${latest.errors.length} 个。取得 ${m.latestObservations.length.toLocaleString('en-US')} 条评论样本，其中 ${m.latestObservations.filter(r => r.discovery === '首次发现').length.toLocaleString('en-US')} 条为首次采到，${low.toLocaleString('en-US')} 条为 1–2 星。`, '',
    ...self.flatMap(s => [`${shortName(s.app)}：商店评分 ${s.app.score?.toFixed(4) ?? '未提供'}，累计评分 ${s.app.ratings?.toLocaleString('en-US') ?? '未提供'} 人。本轮采到 ${s.samples.length} 条评论，其中首次采到 ${s.newCount} 条、1–2 星 ${s.lowCount} 条。`, '']),
    ...(changes.length ? [`本轮版本变化：${changes.map(c => `${shortName(c)} 从 ${c.before} 改为 ${c.after}`).join('；')}。`, ''] : ['本轮没有发现版本变化。', '']),
    ...(top.length ? [`低分样本中较多提及的主题：${top.map(t => `${t.name}（${t.low} 条）`).join('、')}。主题按关键词标记，可重叠，不代表已经判定具体问题。`, ''] : []),
    '## 各应用本轮情况', '',
    '| 应用 | 身份 | 商店评分 | 样本数 | 首次采到 | 1–2 星 | 采集状态 |',
    '| --- | --- | ---: | ---: | ---: | ---: | --- |',
    ...m.summaries.map(s => `| ${escape(shortName(s.app))} | ${identity(s.app.role)} | ${s.app.score?.toFixed(4) ?? '未提供'} | ${s.fresh ? s.samples.length : '未采到'} | ${s.fresh ? s.newCount : '未采到'} | ${s.fresh ? s.lowCount : '未采到'} | ${s.status} |`), '',
    '## 阅读口径', '',
    '- “首次采到”不等于过去 24 小时新发布。每个应用每轮最多请求最新 100 条评论，样本可能包含更早的内容。',
    '- 商店评分与样本平均分是不同指标。低分指 1–2 星，比例只反映本轮样本。',
    '- 评论原文及开发者回复保留西班牙语。主题由西语关键词自动标记，未逐句翻译，也未判定事实真伪。',
    '- Excel 中的“评论去重”适合阅读，“评论采样”保留每一轮的完整记录。同一评论跨批次出现会保留多次。',
    '- 日期均转为北京时间。商店按 mx/es 请求，不能据此断定每位评论者都位于墨西哥。',
    '- 报告任务每两分钟核对新数据，发现新采集后自动更新同一份 Excel 和本简报，生成可能需要几分钟。',
    ...(latest.errors.length ? ['', '## 本轮失败项目', '', ...latest.errors.map(e => `- ${escape(e.appId)}：${escape(e.error)}`)] : []), '',
  ];
  return lines.join('\n');
}

import {collect} from './automation-tools/google-play-scraper/monitor.mjs';
const result=await collect();
console.log(JSON.stringify({apps:result.apps.length,reviews:result.reviews.length,errors:result.errors.length,finishedAt:result.finishedAt}));
if(!result.apps.length)throw Error('No apps collected; keeping previous published data');

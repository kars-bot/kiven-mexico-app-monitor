import {collect} from './automation-tools/google-play-scraper/monitor.mjs';
import {runRankings} from './automation-tools/google-play-scraper/ranking-job.mjs';
// The isolated ranking worker cannot fail or hold the score/review job open.
const [result]=await Promise.all([collect(),runRankings().catch(()=>null)]);
console.log(JSON.stringify({apps:result.apps.length,reviews:result.reviews.length,errors:result.errors.length,finishedAt:result.finishedAt}));
if(!result.apps.length)throw Error('No apps collected; keeping previous published data');

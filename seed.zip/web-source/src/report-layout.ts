import {day,type Report} from './analytics';
export const W=1600,H=900;
type Text={kind:'text';x:number;y:number;w:number;h:number;text:string;size:number;color:string;bold:boolean};
type Rect={kind:'rect';x:number;y:number;w:number;h:number;color:string};
export type Scene={items:(Text|Rect)[];table:{x:number;y:number;w:number;h:number;rows:string[][]};chart:{x:number;y:number;w:number;h:number;labels:string[];values:number[]}};
const ink='242331',muted='756B79',red='D6002A',green='168747';
const num=(n:number)=>n.toLocaleString('zh-CN');
const pct=(n:number|null)=>n===null?'—':(n*100).toFixed(1)+'%';
export function wrap(value: string, width: number, size: number, maxLines: number) {
 const capacity = width / size * 0.94;
 const weight = (character: string) => {
  if (/[\u2E80-\uFFFF]/u.test(character)) return 1;
  if (/[MWm@]/u.test(character)) return 0.95;
  if (/[ilI.,' !]/u.test(character)) return 0.32;
  if (/[A-ZÁÉÍÓÚÜÑ]/u.test(character)) return 0.75;
  return 0.6;
 };
 const measure = (text: string) => Array.from(text).reduce((total, character) => total + weight(character), 0);
 const tokens = value.replace(/\r/g, '').match(/\n|[^\S\n]+|[A-Za-zÀ-ÖØ-öø-ÿ0-9]+|./gu) ?? [];
 const lines: string[] = [];
 let line = '', used = 0;
 const finishLine = () => {
  lines.push(line.trimEnd());
  line = '';
  used = 0;
 };
 for (const token of tokens) {
  if (token === '\n') {
   finishLine();
   continue;
  }
  if (line && used + measure(token) > capacity) finishLine();
  if (!line && /^\s+$/u.test(token)) continue;
  for (const character of token) {
   if (line && used + weight(character) > capacity) finishLine();
   line += character;
   used += weight(character);
  }
 }
 if (line) finishLine();
 const visible = lines.slice(0, maxLines);
 if (lines.length > maxLines && visible.length) {
  let last = visible[visible.length - 1].trimEnd();
  while (last && measure(last + '…') > capacity) last = Array.from(last).slice(0, -1).join('');
  visible[visible.length - 1] = last + '…';
 }
 return visible.join('\n');
}
export function scene(r: Report): Scene {
 const items: Scene['items'] = [];
 const text = (x: number, y: number, w: number, h: number, value: string, size = 22, color = ink, bold = false) => {
  items.push({kind: 'text', x, y, w, h, text: value, size, color, bold});
 };
 const rect = (x: number, y: number, w: number, h: number, color: string) => {
  items.push({kind: 'rect', x, y, w, h, color});
 };
 const shortDate = (value: string) => value.slice(5).replace('-', '/');

 rect(0, 0, W, H, 'FFFFFF');
 text(40, 28, 1120, 48, wrap(r.app.name + ' · 商店评分', 1120, 36, 1), 36, ink, true);
 text(40, 84, 1120, 28, `${r.start} 至 ${r.end}`, 22, muted);
 text(1250, 40, 310, 28, 'Google Play · 墨西哥', 21, muted);

 const cards = [
  {label: '商店评分', value: r.app.score?.toFixed(2) + ' ★', note: '', color: red},
  {label: '累计评分人数', value: num(r.app.ratings ?? 0), note: '', color: ink},
  {label: '评论样本', value: num(r.reviews.length), note: '', color: ink},
  {label: '5 星好评', value: num(r.stars[0].count), note: pct(r.stars[0].share), color: green},
  {label: `${r.lowMax === 1 ? '1 星' : '1–2 星'}差评`, value: num(r.bad.length), note: pct(r.reviews.length ? r.bad.length / r.reviews.length : null), color: red},
  {label: 'Top10 5星好评率', value: pct(r.top10?.share ?? null), note: r.top10 ? `${shortDate(r.top10.day)} · ${r.top10.fiveStarCount}/${r.top10.sampleCount} 条` : '暂无快照', color: green},
 ];
 cards.forEach((card, i) => {
  const x = 40 + i * 256;
  rect(x, 132, 240, 134, 'F8F5F7');
  rect(x, 132, 4, 134, card.color);
  text(x + 16, 145, 216, 28, card.label, 21, muted);
  text(x + 16, 180, 216, 56, card.value, card.value.length > 8 ? 36 : 48, card.color, true);
  if (card.note) text(x + 16, 238, 216, 26, card.note, 20, muted);
 });

 text(40, 292, 870, 34, '星级分布', 27, ink, true);
 const rows = [
  ['星级', '条数', '占比', '上期占比', '变化 / 百分点'],
  ...r.stars.map(star => [
   `${star.score} 星`, num(star.count), pct(star.share), pct(star.previous),
   star.delta === null ? '—' : (star.delta >= 0 ? '+' : '') + (star.delta * 100).toFixed(1),
  ]),
 ];
 text(40, 600, 870, 27, `上期 ${r.previous.start} 至 ${r.previous.end}`, 20, muted);
 text(40, 644, 870, 34, '主要差评主题', 27, ink, true);
 const topics = r.topics.slice(0, 4);
 if (!topics.length) text(40, 714, 870, 50, '所选时段暂无差评样本', 24, muted);

 text(960, 292, 410, 34, '差评与客服回复', 27, ink, true);
 text(1370, 298, 190, 28, r.bad.length ? `已回复 ${r.replied.length}/${r.bad.length}` : '暂无差评', 21, muted);
 const caseCount = Math.max(1, r.chosen.length);
 for (let i = 0; i < caseCount; i++) {
  const y = 332 + i * 260;
  const review = r.chosen[i];
  rect(960, y, 600, 250, 'FAF7F9');
  if (!review) {
   text(982, y + 84, 556, 54, '暂无更多差评案例', 24, muted);
   continue;
  }
  text(982, y + 12, 556, 29, `${review.score} 星 · ${shortDate(day(review.date))} · 翻译`, 23, red, true);
  const translated = wrap(review.translationZh || '请补充翻译', 556, 23, 3);
  text(982, y + 47, 556, 84, translated, 23, ink);
  text(982, y + 135, 556, 24, wrap('西语原文 ' + (review.text || '（无正文）'), 556, 18, 1), 18, muted);
  text(982, y + 163, 556, 25, review.replyText ? '客服回复' : '暂未采到客服回复', 20, muted, true);
  if (review.replyText) {
   text(982, y + 193, 556, 51, wrap(review.replyText, 556, 21, 2), 21, muted);
  }
 }

 text(40, 855, 1520, 26, `评论为采集样本，主题可重叠。商店快照 ${day(r.snapshotAt)}，原文与口径见备注。`, 19, muted);
 return {
  items,
  table: {x: 40, y: 340, w: 870, h: 252, rows},
  chart: {x: 40, y: 690, w: 870, h: 142, labels: topics.map(topic => topic.name), values: topics.map(topic => topic.count)},
 };
}

const esc=(s:string)=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export function svgReport(r:Report){const s=scene(r);let out=`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"><title>${esc(r.app.name)} 商店评分周会报告</title><g font-family="Arial, PingFang SC, Microsoft YaHei, sans-serif">`;
 for(const it of s.items)if(it.kind==='rect')out+=`<rect x="${it.x}" y="${it.y}" width="${it.w}" height="${it.h}" fill="#${it.color}"/>`;else out+=`<text fill="#${it.color}" font-size="${it.size}" font-weight="${it.bold?700:400}">${it.text.split('\n').map((line,i)=>`<tspan x="${it.x}" y="${it.y+it.size+i*it.size*1.2}">${esc(line)}</tspan>`).join('')}</text>`;
 const t=s.table;for(let row=0;row<t.rows.length;row++){out+=`<rect x="${t.x}" y="${t.y+row*42}" width="${t.w}" height="42" fill="${row===0?'#F1EDF1':row%2?'#FFFFFF':'#FAF7F9'}"/>`;t.rows[row].forEach((v,col)=>{out+=`<text x="${t.x+16+col*174}" y="${t.y+row*42+29}" fill="#${row===0?muted:ink}" font-size="21" font-weight="${row===0?700:400}">${esc(v)}</text>`})}
 const c=s.chart; c.labels.forEach((v,i)=>{const y=c.y+i*c.h/Math.max(c.labels.length,1);out+=`<text x="${c.x}" y="${y+24}" fill="#${ink}" font-size="22">${esc(v)}</text><rect x="${c.x+200}" y="${y+5}" width="590" height="18" fill="#F5EAF0"/><rect x="${c.x+200}" y="${y+5}" width="${590*c.values[i]/Math.max(...c.values,1)}" height="18" fill="#${red}"/><text x="${c.x+816}" y="${y+24}" font-size="22" fill="#${red}">${c.values[i]} 条</text>`});return out+'</g></svg>'}
export function saveBlob(blob:Blob,name:string){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000)}
export function reportFilename(r:Report){return `${r.app.name.replace(/[<>:"/\\|?*]/g,'_')}_商店评分_${r.start}_${r.end}`}
export async function downloadPng(r:Report){await document.fonts.ready;const img=new Image(),url=URL.createObjectURL(new Blob([svgReport(r)],{type:'image/svg+xml;charset=utf-8'}));try{await new Promise<void>((resolve,reject)=>{img.onload=()=>resolve();img.onerror=()=>reject(Error('图片生成失败'));img.src=url});const canvas=document.createElement('canvas');canvas.width=3200;canvas.height=1800;canvas.getContext('2d')!.drawImage(img,0,0,3200,1800);const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('图片生成失败')),'image/png'));saveBlob(blob,reportFilename(r)+'.png')}finally{URL.revokeObjectURL(url)}}
let library:Promise<any>|undefined;
async function pptxLibrary(){return library??=(new Promise((resolve,reject)=>{if((window as any).PptxGenJS)return resolve((window as any).PptxGenJS);const script=document.createElement('script');script.src=new URL('vendor/pptxgen.bundle.js',document.baseURI).href;script.onload=()=>resolve((window as any).PptxGenJS);script.onerror=()=>{library=undefined;script.remove();reject(Error('PPT 组件加载失败，请刷新重试'))};document.head.append(script)}))}
// Browser download is generated locally; it needs no account, token, or remote export service.
export function buildPptx(PptxGenJS:any,r:Report){const pptx=new PptxGenJS();pptx.defineLayout({name:'KIVEN',width:16,height:9});pptx.layout='KIVEN';pptx.author='Kiven';pptx.subject='Google Play 墨西哥商店评分样本';pptx.title=reportFilename(r);pptx.lang='zh-CN';pptx.theme={headFontFace:'Microsoft YaHei',bodyFontFace:'Microsoft YaHei',lang:'zh-CN'};const slide=pptx.addSlide(),s=scene(r);
 for(const it of s.items)if(it.kind==='rect')slide.addShape(pptx.ShapeType.rect,{x:it.x/100,y:it.y/100,w:it.w/100,h:it.h/100,line:{color:it.color,transparency:100},fill:{color:it.color}});else slide.addText(it.text,{x:it.x/100,y:it.y/100,w:it.w/100,h:it.h/100,fontSize:it.size*.72,color:it.color,bold:it.bold,fontFace:'Microsoft YaHei',margin:0,breakLine:false,paraSpaceAfter:0,lineSpacingMultiple:1.0,valign:'top'});
 const t=s.table;slide.addTable(t.rows.map((row,i)=>row.map(text=>({text,options:{fill:i===0?'F1EDF1':i%2?'FFFFFF':'FAF7F9',bold:i===0,color:i===0?muted:ink}}))),{x:t.x/100,y:t.y/100,w:t.w/100,h:t.h/100,colW:[1.74,1.74,1.74,1.74,1.74],rowH:.42,fontFace:'Microsoft YaHei',fontSize:15.12,margin:[.04,.16,.04,.16],border:{type:'solid',color:'FFFFFF',pt:0},autoPage:false,verbose:false});
 const c=s.chart;if(c.values.length)slide.addChart(pptx.ChartType.bar,[{name:'差评样本数',labels:[...c.labels].reverse(),values:[...c.values].reverse()}],{x:c.x/100,y:c.y/100,w:c.w/100,h:c.h/100,barDir:'bar',catAxisLabelFontFace:'Microsoft YaHei',catAxisLabelFontSize:15,valAxisLabelFontSize:10,showValue:true,dataLabelPosition:'outEnd',dataLabelFormatCode:'0" 条"',dataLabelColor:red,dataLabelBkgrdColor:'FFFFFF',dataLabelFontSize:15,showLegend:false,showTitle:false,showBorder:false,showCatName:false,catAxisLineShow:false,valAxisLineShow:false,catGridLine:{style:'none'},valGridLine:{style:'none'},valAxisHidden:true,catAxisLabelColor:ink,chartColors:[red],showShadow:false,invertedColors:[red],showMarker:false,showLine:false,showSerName:false,barGapWidthPct:250});
 slide.addNotes([`数据来源：${r.app.url}\n采集快照：${r.snapshotAt}\n历史采集起点：${r.collectionStart}\n评论发布日期范围（北京时间）：${r.start} 至 ${r.end}\n每应用每轮最多采最新100条评论，跨轮按评论ID去重。样本不代表商店全量，等长上期无样本时不计算占比变化。主题按西语关键词归类，可重叠，报告展示前4项。评论及客服回复显示节选，下方保留案例全文。\nTop10 口径：所选时段内最新有数据的北京时间采集日。按最相关排序取前 10 条，五星条数除以实际采到的条数。\n${r.top10?`Top10 采集日 ${r.top10.day}，${pct(r.top10.share)}（${r.top10.fiveStarCount}/${r.top10.sampleCount} 条）。`:'所选时段暂无 Top10 数据。'}\n以下为右侧所选差评及客服回复全文：`,...r.chosen.map((v,i)=>`\n${i+1}. 评论 ID：${v.id}\n星级：${v.score}\n评论时间：${v.date}\n中文主题：${v.themes.join('、')||'未匹配'}\n翻译：${v.translationZh||'未提供'}\n西语原文：${v.text}\n客服回复时间：${v.replyDate||'未提供'}\n客服回复：${v.replyText||'尚未采到回复'}`)].join('\n'));return pptx;}
export async function downloadPptx(r:Report){const PptxGenJS=await pptxLibrary();const pptx=buildPptx(PptxGenJS,r);await pptx.writeFile({fileName:reportFilename(r)+'.pptx',compression:true})}

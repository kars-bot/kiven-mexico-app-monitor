import {day,shiftDay,type Report} from './analytics';
export const W=1600,H=900;
type Text={kind:'text';x:number;y:number;w:number;h:number;text:string;size:number;color:string;bold:boolean};
type Rect={kind:'rect';x:number;y:number;w:number;h:number;color:string};
export type Scene={items:(Text|Rect)[];table:{x:number;y:number;w:number;h:number;rows:string[][]};chart:{x:number;y:number;w:number;h:number;labels:string[];values:number[]}};
const ink='242331',muted='756B79',red='D6002A',green='168747';
const num=(n:number)=>n.toLocaleString('zh-CN');
const pct=(n:number|null)=>n===null?'—':(n*100).toFixed(1)+'%';
export function wrap(text:string,width:number,size:number,maxLines:number){
 const lines:string[]=[];let line='',used=0,cut=false;const chars=Array.from(text.replace(/\r/g,''));
 for(let i=0;i<chars.length;i++){const ch=chars[i],weight=/[\u2E80-\uFFFF]/.test(ch)?1:/[MW@]/.test(ch)?.8:/[il.,' !]/.test(ch)?.3:.55;
  if(ch==='\n'||used+weight>width/size){lines.push(line.trimEnd());line=ch==='\n'?'':ch;used=ch==='\n'?0:weight;if(lines.length===maxLines){cut=i<chars.length-1||!!line;line='';break}}
  else{line+=ch;used+=weight}
 }if(line&&lines.length<maxLines)lines.push(line.trimEnd());if(cut&&lines.length)lines[lines.length-1]=lines[lines.length-1].replace(/.{0,2}$/u,'…');return lines.join('\n');
}
export function scene(r:Report):Scene{
 const items:Scene['items']=[];
 const text=(x:number,y:number,w:number,h:number,value:string,size=20,color=ink,bold=false)=>items.push({kind:'text',x,y,w,h,text:value,size,color,bold});
 const rect=(x:number,y:number,w:number,h:number,color:string)=>items.push({kind:'rect',x,y,w,h,color});
 rect(0,0,W,H,'FFFFFF');text(32,20,1330,44,wrap(r.app.name+' · Google Play 商店评分',1330,32,1),32,ink,true);
 text(32,66,1536,26,`${r.start} 至 ${r.end}  ·  墨西哥  ·  评论发布日期按北京时间  ·  ${r.lowMax===1?'差评 = 1 星':'差评 = 1–2 星'}`,18,muted);
 const cards=[['商店综合评分',r.app.score?.toFixed(2)+' ★','最新快照 '+day(r.snapshotAt),red],['商店累计评分人数',num(r.app.ratings??0),'评分人数，非文字评论数',ink],['时段去重评论样本',num(r.reviews.length),'已采集样本，非全量新增',ink],['5 星评论样本',num(r.stars[0].count),'占时段样本 '+pct(r.stars[0].share),green],[`差评样本（${r.lowMax===1?'1 星':'1–2 星'}）`,num(r.bad.length),'占时段样本 '+pct(r.reviews.length?r.bad.length/r.reviews.length:null),red],['Top10 5星好评率',pct(r.top10.share),r.top10.sampleCount?`${r.top10.fiveStarCount}/${r.top10.sampleCount} 条 · ${r.top10.coveredDays} 个采集日`:'暂无采集日快照',green]];
 cards.forEach((c,i)=>{const x=32+i*258;rect(x,108,246,132,'F8F5F7');rect(x,108,4,132,c[3]);text(x+16,122,226,28,c[0],18,muted);text(x+16,155,226,53,c[1],c[1].length>8?34:43,c[3],true);text(x+16,212,226,23,c[2],15,muted)});
 text(32,260,870,30,'星级分布与等长上期样本对比',23,ink,true);
 const rows=[['评价星级','时段样本数','时段占比','上期占比','占比变化'],...r.stars.map(s=>[`${s.score} 星`,num(s.count)+' 条',pct(s.share),pct(s.previous),s.delta===null?'—':(s.delta>=0?'+':'')+(s.delta*100).toFixed(1)+' 个百分点'])];
 text(32,525,870,27,`上期 ${r.previous.start} 至 ${r.previous.end}，已采到 ${num(r.before.length)} 条样本`,15,muted);
 text(32,563,870,26,'每日 Top10 5 星占比（采集日，最多展示末 7 天）',18,ink,true);
 const topDays=[];for(let d=r.end;d>=r.start&&topDays.length<7;d=shiftDay(d,-1))topDays.unshift(d);
 topDays.forEach((d,i)=>{const row=r.top10.days.find(t=>t.day===d);text(32+i*124,597,124,23,d.slice(5).replace('-','/')+' '+pct(row?.share??null),16,row?.share!=null?green:muted)});
 text(32,637,870,31,'差评提及的主题',23,ink,true);
 text(32,671,870,26,'按西语关键词归类，可重叠。条数仅代表已采集差评样本。',15,muted);
 const top=r.topics.slice(0,6);if(!top.length)text(32,735,860,50,'所选时段没有已采集的差评样本',21,muted);
 text(944,260,624,32,'所选时段差评与客服回复',23,ink,true);
 text(944,299,624,28,`已采到 ${r.bad.length} 条差评，${r.replied.length} 条有回复  ·  下方展示 ${r.chosen.length} 条`,17,muted);
 for(let i=0;i<2;i++){const y=344+i*240,rw=r.chosen[i];rect(944,y,624,222,'FAF7F9');if(!rw){text(966,y+75,580,55,'没有更多符合条件的差评样本',21,muted);continue}
  text(966,y+12,580,25,wrap(`${rw.score} 星  ·  ${day(rw.date)}  ·  ${rw.themes.join('、')||'未匹配主题'}`,580,16,1),16,red,true);
  const original=wrap(rw.text||'（无正文）',580,19,4),originalH=original.split('\n').length*23,replyY=y+46+originalH+9;
  text(966,y+46,580,originalH,original,19,ink);
  text(966,replyY,580,23,'客服回复'+(rw.replyDate?'  '+day(rw.replyDate):'')+(rw.replyText?'':'：尚未采到回复'),16,muted,true);
  const replyH=y+215-replyY-28;
  text(966,replyY+28,580,replyH,wrap(rw.replyText||'截至最新采集快照，没有客服回复记录。',580,17,Math.max(1,Math.floor(replyH/20.4))),17,muted);
 }
 text(32,842,1536,44,`数据口径：每应用每轮最多采最新 100 条，跨轮按评论 ID 去重。商店评分为 ${day(r.snapshotAt)} 快照。Top10 按最相关排序和采集日统计，时段占比按实采数加权。\n采集始于 ${day(r.collectionStart)}。中文主题非逐句翻译，西语长文为节选，完整原文、回复及逐日 Top10 见 PPT 备注。`,14,muted);
 return {items,table:{x:32,y:300,w:870,h:216,rows},chart:{x:32,y:705,w:870,h:126,labels:top.map(t=>t.name),values:top.map(t=>t.count)}};
}
const esc=(s:string)=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export function svgReport(r:Report){const s=scene(r);let out=`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"><title>${esc(r.app.name)} 商店评分周会报告</title><g font-family="Arial, PingFang SC, Microsoft YaHei, sans-serif">`;
 for(const it of s.items)if(it.kind==='rect')out+=`<rect x="${it.x}" y="${it.y}" width="${it.w}" height="${it.h}" fill="#${it.color}"/>`;else out+=`<text fill="#${it.color}" font-size="${it.size}" font-weight="${it.bold?700:400}">${it.text.split('\n').map((line,i)=>`<tspan x="${it.x}" y="${it.y+it.size+i*it.size*1.2}">${esc(line)}</tspan>`).join('')}</text>`;
 const t=s.table;for(let row=0;row<t.rows.length;row++){out+=`<rect x="${t.x}" y="${t.y+row*36}" width="${t.w}" height="36" fill="${row===0?'#F1EDF1':row%2?'#FFFFFF':'#FAF7F9'}"/>`;t.rows[row].forEach((v,col)=>{out+=`<text x="${t.x+16+col*174}" y="${t.y+row*36+25}" fill="#${row===0?muted:ink}" font-size="18" font-weight="${row===0?700:400}">${esc(v)}</text>`})}
 const c=s.chart; c.labels.forEach((v,i)=>{const y=c.y+i*21;out+=`<text x="${c.x}" y="${y+18}" fill="#${ink}" font-size="17">${esc(v)}</text><rect x="${c.x+180}" y="${y+5}" width="620" height="15" fill="#F5EAF0"/><rect x="${c.x+180}" y="${y+5}" width="${620*c.values[i]/Math.max(...c.values,1)}" height="15" fill="#${red}"/><text x="${c.x+816}" y="${y+18}" font-size="17" fill="#${red}">${c.values[i]} 条</text>`});return out+'</g></svg>'}
export function saveBlob(blob:Blob,name:string){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000)}
export function reportFilename(r:Report){return `${r.app.name.replace(/[<>:"/\\|?*]/g,'_')}_商店评分_${r.start}_${r.end}`}
export async function downloadPng(r:Report){await document.fonts.ready;const img=new Image(),url=URL.createObjectURL(new Blob([svgReport(r)],{type:'image/svg+xml;charset=utf-8'}));try{await new Promise<void>((resolve,reject)=>{img.onload=()=>resolve();img.onerror=()=>reject(Error('图片生成失败'));img.src=url});const canvas=document.createElement('canvas');canvas.width=3200;canvas.height=1800;canvas.getContext('2d')!.drawImage(img,0,0,3200,1800);const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('图片生成失败')),'image/png'));saveBlob(blob,reportFilename(r)+'.png')}finally{URL.revokeObjectURL(url)}}
let library:Promise<any>|undefined;
async function pptxLibrary(){return library??=(new Promise((resolve,reject)=>{if((window as any).PptxGenJS)return resolve((window as any).PptxGenJS);const script=document.createElement('script');script.src=new URL('vendor/pptxgen.bundle.js',document.baseURI).href;script.onload=()=>resolve((window as any).PptxGenJS);script.onerror=()=>{library=undefined;script.remove();reject(Error('PPT 组件加载失败，请刷新重试'))};document.head.append(script)}))}
// Browser download is generated locally; it needs no account, token, or remote export service.
export function buildPptx(PptxGenJS:any,r:Report){const pptx=new PptxGenJS();pptx.defineLayout({name:'KIVEN',width:16,height:9});pptx.layout='KIVEN';pptx.author='Kiven';pptx.subject='Google Play 墨西哥商店评分样本';pptx.title=reportFilename(r);pptx.lang='zh-CN';pptx.theme={headFontFace:'Microsoft YaHei',bodyFontFace:'Microsoft YaHei',lang:'zh-CN'};const slide=pptx.addSlide(),s=scene(r);
 for(const it of s.items)if(it.kind==='rect')slide.addShape(pptx.ShapeType.rect,{x:it.x/100,y:it.y/100,w:it.w/100,h:it.h/100,line:{color:it.color,transparency:100},fill:{color:it.color}});else slide.addText(it.text,{x:it.x/100,y:it.y/100,w:it.w/100,h:it.h/100,fontSize:it.size*.72,color:it.color,bold:it.bold,fontFace:'Microsoft YaHei',margin:0,breakLine:false,paraSpaceAfter:0,lineSpacingMultiple:1.0,valign:'top'});
 const t=s.table;slide.addTable(t.rows.map((row,i)=>row.map(text=>({text,options:{fill:i===0?'F1EDF1':i%2?'FFFFFF':'FAF7F9',bold:i===0,color:i===0?muted:ink}}))),{x:t.x/100,y:t.y/100,w:t.w/100,h:t.h/100,colW:[1.74,1.74,1.74,1.74,1.74],rowH:.36,fontFace:'Microsoft YaHei',fontSize:12.96,margin:[.04,.16,.04,.16],border:{type:'solid',color:'FFFFFF',pt:0},autoPage:false,verbose:false});
 const c=s.chart;if(c.values.length)slide.addChart(pptx.ChartType.bar,[{name:'差评样本数',labels:[...c.labels].reverse(),values:[...c.values].reverse()}],{x:c.x/100,y:c.y/100,w:c.w/100,h:c.h/100,barDir:'bar',catAxisLabelFontFace:'Microsoft YaHei',catAxisLabelFontSize:12,valAxisLabelFontSize:10,showValue:true,dataLabelPosition:'outEnd',dataLabelFormatCode:'0" 条"',dataLabelColor:red,dataLabelBkgrdColor:'FFFFFF',dataLabelFontSize:12,showLegend:false,showTitle:false,showBorder:false,showCatName:false,catAxisLineShow:false,valAxisLineShow:false,catGridLine:{style:'none'},valGridLine:{style:'none'},valAxisHidden:true,catAxisLabelColor:ink,chartColors:[red],showShadow:false,invertedColors:[red],showMarker:false,showLine:false,showSerName:false,barGapWidthPct:80});
 slide.addNotes([`数据来源：${r.app.url}\n采集快照：${r.snapshotAt}\n历史采集起点：${r.collectionStart}\n评论发布日期范围（北京时间）：${r.start} 至 ${r.end}\n样本不代表商店全量，等长上期无样本时不计算占比变化。\nTop10 口径：MOST_RELEVANT，5 星条数 / 实采前10条。按北京时间采集日，每日首个成功快照，优先11:30后。跨日不去重，时段按实采数加权。缺失不当0%。\n时段 Top10：${r.top10.fiveStarCount}/${r.top10.sampleCount}，${pct(r.top10.share)}，覆盖${r.top10.coveredDays}天。\n逐日Top10：\n${r.top10.days.map(d=>`${d.day} ${pct(d.share)} (${d.fiveStarCount}/${d.sampleCount}) 实采${d.capturedAt}`).join('\n')}\n以下为右侧所选差评及客服回复全文：`,...r.chosen.map((v,i)=>`\n${i+1}. 评论 ID：${v.id}\n星级：${v.score}\n评论时间：${v.date}\n中文主题：${v.themes.join('、')||'未匹配'}\n西语原文：${v.text}\n客服回复时间：${v.replyDate||'未提供'}\n客服回复：${v.replyText||'尚未采到回复'}`)].join('\n'));return pptx;}
export async function downloadPptx(r:Report){const PptxGenJS=await pptxLibrary();const pptx=buildPptx(PptxGenJS,r);await pptx.writeFile({fileName:reportFilename(r)+'.pptx',compression:true})}

import {useMemo,useState,useEffect} from 'react';
import {Download,Presentation,Image as ImageIcon} from 'lucide-react';
import {day,shiftDay,reportModel,type Review,type App,type TopReviewDay} from './analytics';
import {svgReport,downloadPng,downloadPptx} from './report-layout';
import {translationKey,translateReview,saveReviewTranslation} from './review-translation';
export default function WeeklyReport({apps,reviews,start,end,onDates,snapshotAt,collectionStart,themes,appId,onApp,topRows}:{apps:App[];reviews:Review[];start:string;end:string;onDates:(start:string,end:string)=>void;snapshotAt:string;collectionStart:string;themes:string[];appId:string;onApp:(id:string)=>void;topRows:TopReviewDay[]}){
 const [lowMax,setLowMax]=useState(2),[selected,setSelected]=useState<string[]>([]),[busy,setBusy]=useState(''),[message,setMessage]=useState('');
 const [translations,setTranslations]=useState<Record<string,string>>({});
 const [translationPending,setTranslationPending]=useState(false);
 const app=apps.find(a=>a.appId===appId)??apps.find(a=>a.role==='self')??apps[0];
 const until=end||day(snapshotAt),since=start||shiftDay(until,-6),valid=since<=until;
 useEffect(()=>setSelected([]),[app?.appId,since,until,lowMax]);
 const baseReport=useMemo(()=>app&&valid?reportModel(app,reviews,since,until,lowMax,themes,selected,snapshotAt,collectionStart,topRows):null,[app,reviews,since,until,lowMax,themes,selected,snapshotAt,collectionStart,topRows,valid]);
 const chosenSignature=JSON.stringify(baseReport?.chosen.map(translationKey)??[]);
 useEffect(()=>{
  let active=true;
  const chosen=baseReport?.chosen??[];
  setTranslationPending(chosen.length>0);
  Promise.allSettled(chosen.map(async review=>{
   const text=await translateReview(review);
   if(!active)return;
   const key=translationKey(review);
   setTranslations(current=>Object.prototype.hasOwnProperty.call(current,key)?current:{...current,[key]:text});
  })).then(()=>{if(active)setTranslationPending(false)});
  return()=>{active=false};
 },[chosenSignature]);
 const report=useMemo(()=>baseReport?{
  ...baseReport,
  chosen:baseReport.chosen.map(review=>({...review,translationZh:translations[translationKey(review)]??''})),
 }:null,[baseReport,translations]);
 const missingTranslation=!!report?.chosen.some(review=>!review.translationZh.trim());
 function editTranslation(review:Review,value:string){
  const key=translationKey(review);
  setTranslations(current=>({...current,[key]:value}));
  saveReviewTranslation(review,value);
 }
 const svg=useMemo(()=>report?svgReport(report):'',[report]);
 async function download(kind:string){if(!report||missingTranslation)return;setBusy(kind);setMessage('');try{await(kind==='pptx'?downloadPptx(report):downloadPng(report));setMessage('已生成下载文件。PPT 保留可编辑文字、表格和图表，完整评论在备注中。')}catch(e){setMessage(e instanceof Error?e.message:'下载失败，请重试')}finally{setBusy('')}}
 if(!app)return <section className="panel">没有符合应用筛选条件的数据。</section>;
 return <section className="weekly-report"><div className="panel report-settings"><div><h2><Presentation size={20}/>周会评分报告</h2><p>选择应用和时段，预览后下载。</p></div><div className="report-controls"><label>报告应用<select aria-label="报告应用" value={app.appId} onChange={e=>onApp(e.target.value)}>{apps.map(a=><option key={a.appId} value={a.appId}>{a.name} · {a.title}</option>)}</select></label><label>报告开始日期<input aria-label="报告开始日期" type="date" value={since} max={until} onChange={e=>onDates(e.target.value,until)} onInput={e=>onDates(e.currentTarget.value,until)} onBlur={e=>onDates(e.currentTarget.value,until)}/></label><label>报告结束日期<input aria-label="报告结束日期" type="date" value={until} min={since} onChange={e=>onDates(since,e.target.value)} onInput={e=>onDates(since,e.currentTarget.value)} onBlur={e=>onDates(since,e.currentTarget.value)}/></label><label>差评口径<select aria-label="报告差评口径" value={lowMax} onChange={e=>setLowMax(Number(e.target.value))}><option value={2}>1–2 星（默认）</option><option value={1}>仅 1 星</option></select></label></div><div className="report-actions"><button className="btn primary-btn" disabled={!!busy||!valid||missingTranslation} onClick={()=>download('pptx')}><Download size={16}/>{busy==='pptx'?'正在生成…':'下载可编辑 PPT'}</button><button className="btn" disabled={!!busy||!valid||missingTranslation} onClick={()=>download('png')}><ImageIcon size={16}/>{busy==='png'?'正在生成…':'下载高清图片'}</button><span>PNG 3200 × 1800，可直接插入幻灯片</span></div>{missingTranslation&&<p role="status" className="report-status">{translationPending?'正在准备差评翻译…':'请展开下方“编辑差评翻译”补充译文后下载。'}</p>}{message&&<p role="status" className="report-status">{message}</p>}</div>
 {!valid?<div role="alert" className="error">开始日期不能晚于结束日期。</div>:report&&<><details className="report-method"><summary>数据口径与完整说明</summary><p>商店评分及累计评分人数来自 {day(snapshotAt)} 快照；评论按所选发布日期去重统计。每轮最多 100 条，历史样本可能不完整。上期为前一个等长时段，无样本时显示“—”。Top10 为最新有数据的采集日中，最相关前 10 条评论的五星占比。差评主题按关键词归类，报告展示前四项，条数可重叠。完整案例与说明见 PPT 备注。</p></details><div className="report-canvas" role="img" aria-label={`${app.name} 商店评分报告预览，${since} 至 ${until}，${report.reviews.length} 条样本，${report.bad.length} 条差评`} dangerouslySetInnerHTML={{__html:svg}}/>
 {report.chosen.length>0&&<details className="panel report-translation-editor"><summary>编辑差评翻译</summary><p>译文可修改，PPT 备注保留完整中西文。</p>{report.chosen.map(review=><label key={translationKey(review)}><span>{review.score} 星 · {day(review.date)}</span><textarea aria-label={`差评翻译 ${review.id}`} rows={4} value={review.translationZh} placeholder={translationPending?'正在翻译…':'填写翻译'} onChange={event=>editTranslation(review,event.target.value)}/></label>)}</details>}
 <details className="panel report-choices"><summary>选择差评案例</summary><p>默认展示最近两条，可选择 1–2 条。展开查看原文及客服回复全文。</p><button className="text-btn" onClick={()=>setSelected([])}>恢复最近两条</button><div className="report-review-options">{report.bad.map(r=><article className="report-review-option" key={r.id}><label><input aria-label={`选择差评 ${r.id}`} type="checkbox" checked={report.chosen.some(c=>c.id===r.id)} onChange={e=>{const current=report.chosen.map(c=>c.id);if(e.target.checked){if(current.length>=2){setMessage('最多选择两条，请先取消一条。');return}setSelected([...current,r.id])}else{const next=current.filter(id=>id!==r.id);if(!next.length){setMessage('请至少保留一条案例，或点击恢复最近两条。');return}setSelected(next)}}}/><strong>{r.score} 星</strong><time>{day(r.date)}</time><span>{r.themes.join(' / ')||'未匹配主题'}</span><span className="badge">{r.replyText?'有客服回复':'尚未采到回复'}</span></label><details><summary>{r.text?.slice(0,140)||'（无正文）'}{r.text?.length>140?'…':''}</summary><p lang="es">{r.text}</p><h3>客服回复{r.replyDate?' · '+day(r.replyDate):''}</h3><p lang="es">{r.replyText||'截至最新采集快照，尚未采到回复。'}</p></details></article>)}{!report.bad.length&&<p className="report-note">所选日期没有已采集的差评，报告会保留空状态说明。</p>}</div></details></>}
 </section>
}

export type App={appId:string;name:string;title:string;role:string;score:number;ratings:number;reviews:number;installs:string;version:string;developer:string;summary:string;description:string;recentChanges:string;url:string};
export type Review={id:string;appId:string;title:string;score:number;date:string;text:string;replyText?:string;replyDate?:string;themes:string[];discovery:string;version:string};
export type Snapshot={startedAt:string;finishedAt:string;apps:App[];reviews:Review[];changes:{appId:string;title:string;field:string;fieldName:string;before:unknown;after:unknown}[];errors:{appId:string;error:string}[]};
export function day(s:string){const t=Date.parse(s);return Number.isFinite(t)?new Date(t+8*3600000).toISOString().slice(0,10):""}
export function shiftDay(s:string,n:number){return new Date(Date.parse(s+"T00:00:00Z")+n*86400000).toISOString().slice(0,10)}
export function inRange(s:string,start:string,end:string){const d=day(s);return !!d&&(!start||d>=start)&&(!end||d<=end)}
export function uniqueReviews(snapshots:Snapshot[]){const map=new Map<string,Review>();for(const s of [...snapshots].sort((a,b)=>a.startedAt.localeCompare(b.startedAt)))for(const r of s.reviews)map.set(r.appId+":"+r.id,r);return [...map.values()]}
export function periodBounds(start:string,end:string){const length=Math.round((Date.parse(end+"T00:00:00Z")-Date.parse(start+"T00:00:00Z"))/86400000)+1;return {start:shiftDay(start,-length),end:shiftDay(start,-1)}}
export function reportModel(app:App,all:Review[],start:string,end:string,lowMax:number,themes:string[],selected:string[],snapshotAt:string,collectionStart:string){
 const source=all.filter(r=>r.appId===app.appId),reviews=source.filter(r=>inRange(r.date,start,end)).sort((a,b)=>b.date.localeCompare(a.date)||a.id.localeCompare(b.id));
 const previous=periodBounds(start,end),before=source.filter(r=>inRange(r.date,previous.start,previous.end));
 const bad=reviews.filter(r=>r.score<=lowMax),replied=bad.filter(r=>r.replyText?.trim());
 const stars=[5,4,3,2,1].map(score=>{const count=reviews.filter(r=>r.score===score).length,old=before.filter(r=>r.score===score).length;return {score,count,share:reviews.length?count/reviews.length:null,previous:before.length?old/before.length:null,delta:reviews.length&&before.length?count/reviews.length-old/before.length:null}});
 const topicRows=[...themes.map(name=>({name,count:bad.filter(r=>r.themes.includes(name)).length})),{name:"未匹配主题",count:bad.filter(r=>!r.themes.length).length}].filter(t=>t.count>0).sort((a,b)=>b.count-a.count);
 const chosen=selected.length?selected.map(id=>bad.find(r=>r.id===id)).filter((r):r is Review=>!!r).slice(0,2):bad.slice(0,2);
 return {app,start,end,lowMax,reviews,previous,before,bad,replied,stars,topics:topicRows,chosen,snapshotAt,collectionStart};
}
export type Report=ReturnType<typeof reportModel>;

import type {Review} from './analytics';

// Draft translations are tied to the complete original text.
const initialTranslations: Pick<Review,'appId'|'id'|'text'|'translationZh'>[] = [
  {
    "appId": "com.kiven.mx",
    "id": "22d122d8-a10e-4d3b-96df-653bb01ece70",
    "text": "yo liquide mi prestamo mucho antes del tiempo y no te vuelven a dar no pasa de se agotó el tiempo de saldo nonla descarguen",
    "translationZh": "我很早就提前还清了贷款，但他们不再给我放款，一直停留在“余额有效期已过”的提示。别下载。"
  },
  {
    "appId": "com.mexicash.app",
    "id": "5a6be1bf-d3c2-4aa7-9d93-5279b8c32800",
    "text": "Alamadre no sabía que el interés era el doble jajajaja literal me había aparecido el total de 3,500 por eso solicite el préstamo y al final me sale que tengo que pagar 5,700 jajajaja está muy mal pero pues con esta calificación evito que alguien descargue está aplicación toda estafa, a la otra mejor eviten estar con sus anuncios fastidiosos y desesperantes si al final quedarán mal",
    "translationZh": "真没想到利息竟然是双倍的，哈哈哈。之前明明显示总额为3,500，所以我才申请贷款，最后却显示要还5,700，太离谱了。我给这个差评，就是为了让其他人别下载这个应用，简直是骗局。下次别再投那些烦人又让人焦虑的广告了，结果却根本做不到。"
  },
  {
    "appId": "com.mexicash.app",
    "id": "f6e8c67a-61d8-412d-95aa-16cf44328f60",
    "text": "NO RECOMIENDO ESTA APLICACIÓN PORQUE TE COBRA INTERESES MUY ALTOS Y ALARTE TE AMENASAN Y TE ROBAN TODOS TUS DATOS PERSONALES COMO INE RFC CURP FOTOS Y TODOS TUS CONTACTOS Y TE AMEDENTRAN CON AMENAZAS NO LA DESCARGEN POR FAVOR MUY MALA APLICACIÓN NI LOCA ME COMUNICO CON USTEDES PARA QUE ME ESTEN AMENDRENTANDO Y AMENAZANDO TENGO PRUEBAS LASTIMA QUE NO LAS PUEDO SUBIR AQUI",
    "translationZh": "我不推荐这个应用，利息非常高，还会威胁你，窃取你所有的个人信息，包括INE证件、RFC税号、CURP编号、照片和所有联系人。他们还用威胁来恐吓你。请千万别下载，这个应用真的很差。我绝不会联系你们，再让你们恐吓和威胁我。我有证据，可惜无法在这里上传。"
  }
];

const storageKey = 'kiven-review-translations-v1';
const values = new Map<string, string>();
const requests = new Map<string, Promise<string>>();
let cacheLoaded = false;

export function translationKey(review: Pick<Review, 'appId' | 'id' | 'text'>) {
 return JSON.stringify([review.appId, review.id, review.text]);
}

function loadCache() {
 if (cacheLoaded) return;
 cacheLoaded = true;
 for (const review of initialTranslations) values.set(translationKey(review), review.translationZh!);
 if (typeof window === 'undefined') return;
 try {
  const rows = JSON.parse(window.localStorage.getItem(storageKey) || '[]');
  if (!Array.isArray(rows)) return;
  for (const row of rows) {
   if (Array.isArray(row) && typeof row[0] === 'string' && typeof row[1] === 'string') values.set(row[0], row[1]);
  }
 } catch { /* Translation still works when browser storage is unavailable. */ }
}

export function saveReviewTranslation(review: Review, translation: string) {
 loadCache();
 const key = translationKey(review);
 values.delete(key);
 values.set(key, translation);
 while (values.size > 200) values.delete(values.keys().next().value!);
 if (typeof window === 'undefined') return;
 try { window.localStorage.setItem(storageKey, JSON.stringify([...values])); } catch { /* Keep the current edits in memory. */ }
}

// The public endpoint accepts at most 500 UTF-8 bytes per request.
function splitText(text: string) {
 const encoder = new TextEncoder();
 const chunks: string[] = [];
 let chunk = '';
 for (const token of text.match(/\S+\s*|\s+/gu) ?? []) {
  if (encoder.encode(chunk + token).length > 480 && chunk) {
   chunks.push(chunk.trim());
   chunk = '';
  }
  for (const character of token) {
   if (encoder.encode(chunk + character).length > 480) {
    chunks.push(chunk.trim());
    chunk = '';
   }
   chunk += character;
  }
 }
 if (chunk.trim()) chunks.push(chunk.trim());
 return chunks;
}

export function translateReview(review: Review): Promise<string> {
 loadCache();
 const key = translationKey(review);
 const cached = values.get(key);
 if (values.has(key)) return Promise.resolve(cached ?? '');
 const pending = requests.get(key);
 if (pending) return pending;
 const request = (async () => {
  if (!review.text.trim()) return '（无正文）';
  const translated: string[] = [];
  for (const chunk of splitText(review.text)) {
   const url = new URL('https://api.mymemory.translated.net/get');
   url.searchParams.set('langpair', 'es|zh-CN');
   url.searchParams.set('q', chunk);
   const response = await fetch(url, {redirect: 'error', signal: AbortSignal.timeout(20000)});
   if (!response.ok) throw Error('暂未取得翻译，请在编辑区补充。');
   const result = await response.json();
   const text = result.responseData?.translatedText;
   if (Number(result.responseStatus) !== 200 || typeof text !== 'string' || !/[\u3400-\u9FFF]/u.test(text)) {
    throw Error('暂未取得翻译，请在编辑区补充。');
   }
   translated.push(text.trim());
  }
  const text = translated.join('');
  if (values.has(key)) return values.get(key)!;
  saveReviewTranslation(review, text);
  return text;
 })().finally(() => requests.delete(key));
 requests.set(key, request);
 return request;
}

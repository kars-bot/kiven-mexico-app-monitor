import {useState} from 'react';
import {day,shiftDay,type App,type TopReviewDay} from './analytics';
export const topPercent=(v:number|null)=>v===null?'—':(v*100).toFixed(1)+'%';
export default function TopReviews({apps,rows,start,end,snapshotAt}:{apps:App[];rows:TopReviewDay[];start:string;end:string;snapshotAt:string}){
 const [selected,setSelected]=useState<TopReviewDay|null>(null);
 const until=end||day(snapshotAt),since=start||shiftDay(until,-6),dates:string[]=[];
 for(let d=since;d<=until&&dates.length<366;d=shiftDay(d,1))dates.push(d);
 const map=new Map(rows.map(r=>[r.appId+':'+r.day,r])),visible=[...apps].sort((a,b)=>Number(b.role==='self')-Number(a.role==='self'));
 const chosen=selected&&visible.some(a=>a.appId===selected.appId)&&dates.includes(selected.day)?selected:null;
 return <section className="panel top10-panel"><div className="panel-heading"><div><h2>每日 Top10 5 星好评率</h2><p>商店“最相关”前 10 条 · 点击占比可查看对应评论 · 日期为采集日（北京时间）</p></div><span>{since} 至 {until}</span></div>
 <div className="table-scroll"><table className="top10-table"><thead><tr><th>应用 / 完整标题</th>{dates.map(d=><th key={d}>{d.slice(5).replace('-','/')}</th>)}</tr></thead><tbody>{visible.map(a=><tr key={a.appId} className={a.role==='self'?'self-row':''}><td><div className="app-name"><div><b>{a.name}</b>{a.role==='self'&&<span className="badge self">自家</span>}<small title={a.title}>{a.title}</small></div></div></td>{dates.map(d=>{const r=map.get(a.appId+':'+d);return <td key={d}>{r?.share!=null?<button className="top10-value" onClick={()=>setSelected(r)} aria-label={`${a.name} ${d} Top10 五星占比 ${topPercent(r.share)}`} title={`5星 ${r.fiveStarCount}/${r.sampleCount} 条，采集 ${r.capturedAt}`}><strong>{topPercent(r.share)}</strong><small>{r.fiveStarCount}/{r.sampleCount} 条</small></button>:<span className="muted" title={r?.status==='failed'?'当日采集失败':'尚无当日快照'}>—</span>}</td>})}</tr>)}</tbody></table></div>
 <p className="top10-foot">5 星占比 = 5 星条数 ÷ 实际采到的前 10 条。每天取首个成功快照，优先 11:30 后；同一评论可在不同日期再次入选。未采集或失败显示“—”，不足 10 条按实采数计算。历史从启用日起累积。{dates.length===366?'当前范围仅显示前 366 天。':''}</p>
 {chosen&&<div className="top10-detail"><div className="panel-heading"><h2>{apps.find(a=>a.appId===chosen.appId)?.name} · {chosen.day} 最相关前 {chosen.sampleCount} 条</h2><button className="text-btn" onClick={()=>setSelected(null)}>收起明细</button></div><p className="muted">实际采集 {new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',dateStyle:'short',timeStyle:'short'}).format(new Date(chosen.capturedAt))}，保留接口返回顺序。商店展示可能因用户或设备而异。</p><ol>{chosen.reviews.map(r=><li key={r.id}><strong>{r.score} 星</strong><time>{day(r.date)}</time><p lang="es">{r.text||'（无正文）'}</p>{r.replyText&&<details><summary>客服回复</summary><p lang="es">{r.replyText}</p></details>}</li>)}</ol></div>}
 </section>
}

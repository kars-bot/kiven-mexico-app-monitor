import {useEffect,useState} from 'react';
import {TrendingUp,RefreshCw} from 'lucide-react';
import {day,shiftDay,type App} from './analytics';
type Capture={capturedAt:string;day:string;status:'ok'|'failed';coverage:number;apps:{appId:string;rank:number|null}[]};
type RankingData={latestAttempt:string|null;days:Capture[];captures:Capture[]};
const normalize=(s:string)=>s.normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase();
const time=(s:string)=>new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(s));
export function movement(current:Capture,previous:Capture|undefined,id:string){
 if(current.status!=='ok')return {text:'采集失败',kind:'muted'};
 if(!previous)return {text:'无昨日样本',kind:'muted'};
 if(previous.status!=='ok')return {text:'昨日采集失败',kind:'muted'};
 const a=current.apps.find(a=>a.appId===id),b=previous.apps.find(a=>a.appId===id);
 if(!a||!b)return {text:'缺少对比数据',kind:'muted'};
 if(a.rank===null)return {text:b.rank===null?'均未见榜单':'离开返回榜单',kind:'muted'};
 if(b.rank===null)return {text:'进入返回榜单',kind:'rank-up'};
 const delta=b.rank-a.rank;return {text:delta>0?'↑ '+delta+' 名':delta<0?'↓ '+Math.abs(delta)+' 名':'— 持平',kind:delta>0?'rank-up':delta<0?'rank-down':'muted'};
}
function Sparkline({days,id}:{days:Capture[];id:string}){
 const w=240,h=64,p=8,positions=days.map((d,i)=>({x:p+i*(w-2*p)/Math.max(1,days.length-1),rank:d.status==='ok'?d.apps.find(a=>a.appId===id)?.rank:null,day:d.day}));
 const valid=positions.filter(p=>p.rank!=null),max=200,y=(r:number)=>p+(r-1)*(h-2*p)/Math.max(1,max-1);
 const segments:string[][]=[];let segment:string[]=[];
 for(const point of positions){if(point.rank==null){if(segment.length)segments.push(segment);segment=[]}else segment.push(`${point.x},${y(point.rank)}`)}if(segment.length)segments.push(segment);
 return <svg className="rank-spark" viewBox={`0 0 ${w} ${h}`} role="img" aria-label={valid.length?valid.map(v=>`${v.day} 第 ${v.rank} 名`).join('；'):'暂无趋势数据'}><line x1={p} x2={w-p} y1={h-p} y2={h-p} stroke="#e8e8ed"/>{segments.map((s,i)=><polyline key={i} points={s.join(' ')} fill="none" stroke="#e00030" strokeWidth="2"/>)}{valid.map(v=><circle key={v.day} cx={v.x} cy={y(v.rank!)} r="3" fill="#e00030"><title>{v.day} · 第 {v.rank} 名</title></circle>)}</svg>
}
export default function Rankings({apps,app,title,role,start,end,selected,onSelect,reload}:{apps:App[];app:string;title:string;role:string;start:string;end:string;selected:string;onSelect:(day:string)=>void;reload:number}){
 const [data,setData]=useState<RankingData|null>(null),[error,setError]=useState(''),[windowDays,setWindowDays]=useState(7);
 useEffect(()=>{const c=new AbortController();let seq=0;async function load(){const request=++seq;try{const r=await fetch(new URL('data/rankings.json',document.baseURI),{cache:'no-store',signal:c.signal});if(!r.ok)throw Error();const next=await r.json();if(!Array.isArray(next.days)||!Array.isArray(next.captures))throw Error();if(request===seq){setData(next);setError('')}}catch(e){if(!c.signal.aborted)setError('排名数据暂时无法读取，请刷新重试。')}}load();const timer=setInterval(load,60000);return()=>{c.abort();clearInterval(timer)}},[reload]);
 if(!data&&!error)return <div className="loading"><RefreshCw className="spin" size={24}/>正在读取商店排名…</div>;
 if(!data)return <div className="error" role="alert">{error}</div>;
 const filtered=data.days.filter(d=>(!start||d.day>=start)&&(!end||d.day<=end)),current=filtered.find(d=>d.day===selected)??filtered.at(-1),latestAttempt=data.captures.at(-1);
 const visible=apps.filter(a=>(!app||a.appId===app)&&(!role||a.role===role)&&(!title||normalize(a.name+' '+a.title+' '+a.appId).includes(normalize(title))));
 const previous=current?data.days.find(d=>d.day===shiftDay(current.day,-1)):undefined;
 const sorted=[...visible].sort((a,b)=>Number(b.role==='self')-Number(a.role==='self')||(current?.apps.find(x=>x.appId===a.appId)?.rank??999)-(current?.apps.find(x=>x.appId===b.appId)?.rank??999));
 const last=current?.day??'',first=start||shiftDay(last||new Date().toISOString().slice(0,10),1-windowDays),rangeEnd=end||last;
 const trendDays:Capture[]=[];if(first&&rangeEnd&&first<=rangeEnd){for(let d=first;d<=rangeEnd&&trendDays.length<366;d=shiftDay(d,1))trendDays.push(data.days.find(x=>x.day===d)??{day:d,capturedAt:'',status:'failed',coverage:0,apps:[]})}
 const good=data.days.filter(d=>d.status==='ok');
 return <div className="rankings-view">
 {error&&<div className="error" role="alert">{error} 当前保留上次读取的数据。</div>}
 <div className="ranking-intro"><div><div className="section-kicker">DAILY CHART SNAPSHOT</div><h2>墨西哥 · 金融类免费榜</h2><p>Google Play 直接采集 · 每天北京时间 11:30 留存快照 · 名次数字越小，排名越靠前</p></div><TrendingUp size={32}/></div>
 {Date.now()>=Date.parse(day(new Date().toISOString())+'T11:30:00+08:00')&&!data.days.some(d=>d.day===day(new Date().toISOString())&&d.status==='ok')&&<div className="freshness warning">今日排名尚未成功更新，当前显示已有历史快照。请以实际采集日期为准。</div>}
 {latestAttempt?.status==='failed'&&<div className="freshness warning">最近一次排名采集失败（{time(latestAttempt.capturedAt)}）。成功历史仍可查看，未把失败记为未上榜。</div>}
 {!current?<section className="panel empty"><h2>{data.days.length?'所选日期内没有排名快照':'排名基准尚未建立'}</h2><p>{data.days.length?'请调整日期范围。':'首次成功采集后会显示排名；历史从启用日起累积。'}</p></section>:<>
 <section className="rank-controls panel"><label>查看日期<select aria-label="排名快照日期" value={current.day} onChange={e=>onSelect(e.target.value)}>{[...filtered].reverse().map(d=><option key={d.day} value={d.day}>{d.day}{d.status!=='ok'?' · 采集失败':''}</option>)}</select></label><div><strong>{current.status==='ok'?`返回 ${current.coverage} 个榜单位置`:'当日采集失败'}</strong><span>实际采集 {time(current.capturedAt)}（北京时间）</span></div><div><strong>{good.length} 天成功快照</strong><span>{good.length===1?'首日基准 · 尚无昨日排名':'较昨日仅比较相邻日成功快照'}</span></div></section>
 <section className="panel"><div className="panel-heading"><div><h2>应用排名与每日变化 <span>{sorted.length} 个应用</span></h2><p>自家产品置顶 · 升降相对 {shiftDay(current.day,-1)} · 趋势越高，排名越好</p></div><div className="rank-period">{!start&&!end&&[7,30].map(n=><button className={'btn '+(windowDays===n?'active':'')} key={n} onClick={()=>setWindowDays(n)}>近 {n} 天</button>)}</div></div>
 <div className="table-scroll"><table className="rank-table"><thead><tr><th>应用 / 完整标题</th><th>{current.day} 排名</th><th>昨日排名</th><th>较昨日变化</th><th>每日趋势{start||end?' · 所选范围':` · 近 ${windowDays} 天`}</th></tr></thead><tbody>{sorted.map(a=>{const r=current.apps.find(r=>r.appId===a.appId),prev=previous?.apps.find(r=>r.appId===a.appId),delta=movement(current,previous,a.appId);return <tr key={a.appId} className={a.role==='self'?'self-row':''}><td><div className="app-name"><span className={'app-icon '+(a.role==='self'?'own':'')}>{a.name.slice(0,1)}</span><div><b>{a.name}</b>{a.role==='self'&&<span className="badge self">自家</span>}<small title={a.title}>{a.title}</small></div></div></td><td><strong className="rank-number">{current.status!=='ok'?'采集失败':r?.rank??'未见榜单'}</strong></td><td>{!previous?'无快照':previous.status!=='ok'?'采集失败':prev?.rank??'未见榜单'}</td><td className={delta.kind}>{delta.text}</td><td><Sparkline days={trendDays} id={a.appId}/><small className="rank-trend-dates">{first} — {rangeEnd}</small></td></tr>})}</tbody></table></div>{!sorted.length&&<div className="empty">没有匹配应用，请调整筛选条件。</div>}
 </section></>}
 <div className="report-note"><strong>排名口径</strong>：这是金融类免费榜的采集时点快照，不是 Google 官方公布的每日结算排名。榜单请求最多 200 个位置，以实际返回数量为准；“未见榜单”仅表示该应用未出现在此次返回列表。首日、缺少昨日快照和采集失败不计算升降。趋势空档不连线，超过 366 天的范围仅画前 366 天。排名不进入周会 PPT；评分和评论保持原有口径。</div>
 </div>
}

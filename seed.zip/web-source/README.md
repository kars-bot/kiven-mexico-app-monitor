# 墨西哥应用监控 · GitHub Pages 版本

正式网址：https://kars-bot.github.io/kiven-mexico-app-monitor/
公开仓库：https://github.com/kars-bot/kiven-mexico-app-monitor

这是不依赖 Sites/Vercel 的 React 静态版本。src 包含页面源码；public/data 包含已导出的公开采集数据；Vite base 为 ./，支持 GitHub Pages 项目子目录。

网页正式数据由仓库中的 GitHub Actions 每天 UTC 03:30（北京时间 11:30）计划采集，发布可能受 GitHub 队列延迟。源代码更新或 seed.zip 更新也会触发完整采集。工作流使用 GitHub 自动提供的 GITHUB_TOKEN，不需要本机账号或自定义密钥。

本地构建：node node_modules/vite/bin/vite.js build。依赖暂复用相邻 Vinext 项目 node_modules；独立环境可按 package.json 安装。生成的数据通过 automation-tools/reporting/export-static-site.mjs 从本机历史导出。此导出器供首次导入和本地验证，正常云端更新使用 seed/publish.mjs。

GitHub 仓库初始源文件：README.md、seed.zip、.github/workflows/monitor.yml。seed.zip 是经过允许列表挑选的网页、源代码、采集脚本与初始公开数据。工作流展开 seed.zip，恢复仓库 history 历史和去重状态，采集、生成网页，然后提交新增历史并通过 Pages 部署。全部采集失败时保留旧网页。工作流源文件保存在 github-release/monitor.yml，初始包明文内容在 github-release/seed。

目前 GitHub 连接器未获得此新仓库的写入权限，创建仓库、上传和工作流设置已通过用户登录的 GitHub 网页完成。今后需要维护可继续使用 GitHub 网页，或由用户在 GitHub App 设置中单独授权此专用仓库。不要复制或索取账户凭据。

旧 chatgpt.site 同步 LaunchAgent 已停用并保留为 .plist.disabled；本机 Activepieces 采集与 Excel 自动更新任务继续保留，本地和网页数据可能来自不同时间的采样。

品牌配色按用户 2026-10-21 提供的 Kiven Logo 更新：亮红 #fe0123、深红 #b80119；文字强调使用较深的 #d6002a，搭配白底与深酒红导航。Logo 原文件直接使用，未改变图像内容。

左侧菜单现可通过 Logo 旁按钮收起或展开，收起为 76 像素图标栏；名称保留在无障碍标签和悬浮提示中。当前浏览器的选择保存在 localStorage，刷新后恢复；不改变 URL 的数据筛选状态。

## 周会报告与日期范围（2026-10-21）

- 全局“评论发布日期”起止日期、近 7 天、近 30 天用于历史评论去重筛选，时区为北京时间。清除日期返回单批次；切换采集批次也会清除日期。
- “周会报告”按单应用和日期范围导出一页 16:9 可编辑 PPTX，或 3200×1800 PNG。五项指标、星级分布、等长上期样本对比、差评主题和两条差评/客服回复共用同一统计模型。
- 默认差评为 1–2 星，也可选择仅 1 星。可手选 1–2 条案例。长原文显示节选，PPT 备注保留所选两条评论及客服回复全文。
- 商店评分和累计评分人数是标注日期的快照，不回推为报告期末数值；日期范围内评论仅为已采集样本，不声称全量。上期没有样本时占比和变化显示“—”。
- 云端 publish.mjs 每轮刷新 data/history.json，保存历史按应用及评论 ID 去重、最新可用正文及回复。index.json 的 historyFile 和 latestBatch 用于一致性校验，前端在历史文件缺失或版本不一致时暂停日期统计及下载，避免静默遗漏。
- PPTX 浏览器端使用随站发布的 PptxGenJS 4.0.1（MIT，许可在 public/vendor），无登录或导出服务依赖。文字、表格、主题图表可编辑。PNG 由同一报告布局生成。


每日 Top10 5 星好评率（2026-11-05 启用）：独立请求 Google Play mx/es 的 MOST_RELEVANT 前 10 条，保留原始顺序和客服回复。按北京时间采集日记录，各应用每日首个成功快照，优先 11:30 后。占比=5星条数/实际返回条数，空、失败及启用前日期均不补零。监控总览支持按应用/标题/身份/日期筛选逐日表和查看原文。周会页及可编辑 PPT/PNG 展示所选时段内最新有数据的采集日、当日五星占比及条数。此指标的日期为采集日，原时段评论统计仍按评论发布日期。

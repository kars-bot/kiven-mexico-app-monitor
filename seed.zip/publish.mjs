import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {websiteData} from './automation-tools/reporting/site-data.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const {index,snapshots,history:reviewHistory,rankings,topReviews}=await websiteData();index.exportedAt=new Date().toISOString();
await fs.mkdir(path.join(root,'site/data/snapshots'),{recursive:true});
for(const [batch,data] of Object.entries(snapshots))await fs.writeFile(path.join(root,'site/data/snapshots',batch.replaceAll(':','-')+'.json'),JSON.stringify(data));
await fs.writeFile(path.join(root,'site/data/index.json'),JSON.stringify(index));
await fs.writeFile(path.join(root,'site/data/history.json'),JSON.stringify(reviewHistory));
await fs.writeFile(path.join(root,'site/data/rankings.json'),JSON.stringify(rankings));
await fs.writeFile(path.join(root,'site/data/top-reviews.json'),JSON.stringify(topReviews));
const input=path.join(root,'automation-tools/google-play-scraper/reports');
const history=path.resolve(root,'../history');await fs.mkdir(history,{recursive:true});
for(const entry of await fs.readdir(input,{withFileTypes:true})){
 if(entry.isDirectory()){
 const source=path.join(input,entry.name,'report.json');
 try{const dest=path.join(history,entry.name);await fs.mkdir(dest,{recursive:true});await fs.copyFile(source,path.join(dest,'report.json'))}catch(e){if(e.code!=='ENOENT')throw e}
 }
}
try{await fs.mkdir(path.join(history,'rankings'),{recursive:true});for(const name of await fs.readdir(path.join(input,'rankings')))if(/^\d{4}-.*\.json$/.test(name))await fs.copyFile(path.join(input,'rankings',name),path.join(history,'rankings',name))}catch(e){if(e.code!=='ENOENT')throw e}
await fs.copyFile(path.join(input,'state.json'),path.join(history,'state.json'));
console.log(JSON.stringify({latest:index.latestBatch,totals:index.totals}));
